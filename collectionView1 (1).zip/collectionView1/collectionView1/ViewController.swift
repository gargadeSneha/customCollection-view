//
//  ViewController.swift
//  collectionView1
//
//  Created by TryCatch Classes on 23/06/1944 Saka.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    var ProductName = ["Sofa","Headphone","BrandedWatch","Table","Perfume","Chair","Goggles","Speaker","Watch","Cup"]
    
    var ProductImage = ["Sofa","Headphone","BrandedWatch","Table","Perfume","Chair","Goggals","Speaker","Watch","Cup"]
    
    
   // var ProductOldPrice = ["Rs 20,000","Rs 7,000","Rs 5,000","Rs 1,000","Rs 15,000","Rs 1,000","Rs 10,000","Rs 12,000","Rs 700","Rs 1,000"]
    
    var ProductNewPrice = ["Rs. 10,000",
                        "Rs 3,000",
                        "Rs 2,000",
                        "Rs 800",
                        "Rs 999",
                        "Rs 700",
                        "Rs 8,000",
                        "Rs 1,000",
                        "Rs 400",
                        "Rs 899"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        collectionView.dataSource = self
        collectionView.delegate = self
        
    }


}
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCVC
        cell.myImage.image = UIImage(named: ProductImage[indexPath.row])
        cell.myLabel.text = ProductName[indexPath.row]
        cell.newPriceLabel.text = ProductNewPrice[indexPath.row]
        
      //  cell.oldPriceLabel.text = ProductOldPrice[indexPath.row]
        
        cell.layer.cornerRadius = 10
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = ((collectionView.frame.width - 30) / 2)
        let height = ((collectionView.frame.height - 70) / 3)
        
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLLayout:
                        UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 20, left: 10, bottom: 20, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt Section: Int) -> CGFloat{
        
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt Section: Int) -> CGFloat{
        
        return 15
    }
    
}

