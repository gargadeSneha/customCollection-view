//
//  CustomCVC.swift
//  collectionView1
//
//  Created by TryCatch Classes on 23/06/1944 Saka.
//

import UIKit

class CustomCVC: UICollectionViewCell {
    

    @IBOutlet weak var myLabel: UILabel!

    @IBOutlet weak var myImage: UIImageView!
    
   // @IBOutlet weak var oldPriceLabel: UILabel!
    
    
    @IBOutlet weak var newPriceLabel: UILabel!
}
